const webpack = require("webpack")
const HtmlWebpackPlugin = require("html-webpack-plugin")
const CleanWebpackPlugin = require("clean-webpack-plugin")


module.exports = {
    entry: __dirname + "/src/main.js",
    output: {
        path: __dirname + "/dist",
        filename: "[name].js",
    },
    plugins: [
        new CleanWebpackPlugin("dist"),
        new webpack.HotModuleReplacementPlugin(),
        new HtmlWebpackPlugin({
            filename: "index.html",
            path: __dirname + "/dist",
            template: "./index.html",
        })
    ],
    module: {
        rules: [
            { test: /\.js$|\.jsx$/, use: ["babel-loader"], exclude: /node_modules/ },
            { test: /\.css$/, use: ["style-loader", "css-loader",], exclude: /node_modules/ },
        ]
    },
    devServer: {
        port: 3000,
        open: 'http://localhost:3000',
        contentBase: __dirname,
        inline: true,
        hot: true
    },
}